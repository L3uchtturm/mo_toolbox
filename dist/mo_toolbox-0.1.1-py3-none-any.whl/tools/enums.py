from enum import Enum


class Vermessung(Enum):
    pass
